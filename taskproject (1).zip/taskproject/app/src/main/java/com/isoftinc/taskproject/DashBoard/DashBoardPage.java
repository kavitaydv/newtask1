package com.isoftinc.taskproject.DashBoard;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.view.GravityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.isoftinc.taskproject.Fragment.HomeFragment;
import com.isoftinc.taskproject.R;
import com.isoftinc.taskproject.Splash.SessionData;
import com.isoftinc.taskproject.databinding.ActivityDashboardPageBinding;

public class DashBoardPage extends AppCompatActivity {

    private ActivityDashboardPageBinding binding;
    private SessionData session;
    public static GoogleSignInOptions signInOptions;
    @SuppressLint("StaticFieldLeak")
    public static GoogleSignInClient signInClient;
    private TextView userNameDrawer;
    private RelativeLayout home;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityDashboardPageBinding.inflate(getLayoutInflater());
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        setContentView(binding.getRoot());
        userNameDrawer = findViewById(R.id.userNameDrawer);
        home = findViewById(R.id.home);
        session = new SessionData(this);

        userNameDrawer.setText(session.GetSharedPreferences(SessionData.user_name));

        binding.menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (binding.drawerLayout.isDrawerOpen(binding.navigationView)) {
                    binding.drawerLayout.closeDrawer(binding.navigationView);

                } else {
                    binding.drawerLayout.openDrawer(binding.navigationView);

                }
            }
        });

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                binding.drawerLayout.closeDrawer(binding.navigationView);
                Fragment fragment = new HomeFragment();
                FragmentManager manager = getSupportFragmentManager();
                FragmentTransaction transaction = manager.beginTransaction();
                transaction.replace(R.id.navHostFragment,fragment);
                transaction.commit();

            }
        });
    }

    @Override
    public void onBackPressed() {
        if (session.GetSharedPreferences(SessionData.page_name).equalsIgnoreCase("Home")) {
           finish();
        }
    }
}