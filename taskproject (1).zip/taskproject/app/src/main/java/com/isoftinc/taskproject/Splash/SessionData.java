package com.isoftinc.taskproject.Splash;
import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class SessionData {
  // Shared Preferences
  SharedPreferences pref;

  // Editor for Shared preferences
  SharedPreferences.Editor editor;

  // Context
  Context _context;

  // Shared pref mode
  int PRIVATE_MODE = 0;

  private static final String PREF_NAME = "Boosterprefrence_playzon";
  public static final String user_name        = "user_name";
  public static final String page_name        = "page_name";




  // Constructor
  public SessionData(Context context){
    this._context = context;
    pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
    editor = pref.edit();
  }



  public String GetSharedPreferences(String Keytag) {
    SharedPreferences SP = PreferenceManager
            .getDefaultSharedPreferences(_context);
    return SP.getString(Keytag, "");
  }


  public void SetSharedPreferences(String Keytag, String KeyValue) {
    SharedPreferences prefs = PreferenceManager
            .getDefaultSharedPreferences(_context);
    SharedPreferences.Editor spe = prefs.edit();
    spe.putString(Keytag, KeyValue);
    spe.commit();
  }


}
